
REAL COLLISONS OF CHECKSUMS AND ONE WAY HASH FUNCTIONS
======================================================
Document created by Dipl.-Inf. (FH) Johann N. Loefflmann (jonelo@jonelo.de)
for the Jacksum project (http://jacksum.sourceforge.net)
updated on July, 23 2005


See also
http://www.jonelo.de/java/jacksum/index.html#security


Real SHA-1 collisions
---------------------
No real collisions are available today.

http://cryptome.org/wang_sha1_v2.zip
  Finding Collisions in the full SHA-1
  Jun 22, 2005

http://news.zdnet.com/2100-1009_22-5598536.html
  Interview with Yiqun Lisa Yin concerning the attack on SHA-1
  March 3, 2005

http://www.rsasecurity.com/rsalabs/node.asp?id=2834
  SHA1 Status Questionable
  Feb 18, 2005

http://www.schneider.com/blog/archives/2005/02/cryptanalysis_o.html
  Cryptanalysis of SHA-1
  Feb 18, 2005

http://www.schneider.com/blog/archives/2005/02/sha1_broken.html
  SHA-1 Broken
  Feb 15, 2005

http://eprint.iacr.org/2005/010
  Update on SHA-1
  Jan 14, 2005

http://theory.csail.mit.edu/~yiqun/shanote.pdf
  Collision Search Attacks on SHA1
 


Real MD5 collisions
-------------------
On 17 August 2004 a collision for MD5 were announced by researchers
in China: Xiaoyun Wang, Dengguo Feng, Xuejia Lai and Hongbo Yu.

See also:
http://eprint.iacr.org/2004/264/
  Musings on the Wang et al. MD5 Collision
  Oct 13, 2004

http://www.rsasecurity.com/rsalabs/node.asp?id=2738
  Collisions for SHA0, MD5, HAVAL, MD4, and RIPEMD, but SHA1 still secure
  Aug 31, 2004

http://www.md5crk.com (not available anymore)
  The MD5CRK project
  Aug 24, 2004

http://eprint.iacr.org/2004/199/
  Collisions for Hash Functions MD4, MD5, HAVAL-128 and RIPEMD
  Aug 17, 2004


# jacksum -a md5 collision-md5-file-0?
a4c0d35c95a63a805915367dcfe6b751 collision-md5-file-0a
a4c0d35c95a63a805915367dcfe6b751 collision-md5-file-0b

# jacksum -a sha1 collision-md5-file-0?
2783c4ff4a3f20d25f2598a8b052b890c37dcac4 collision-md5-file-0a
3c35410823ef00b12d020981c1cf8564c0f89bcc collision-md5-file-0b


# jacksum -a md5 collision-md5-file-1?
79054025255fb1a26e4bc422aef54eb4 collision-md5-file-1a
79054025255fb1a26e4bc422aef54eb4 collision-md5-file-1b

# jacksum -a sha1 collision-md5-file-1?
a34473cf767c6108a5751a20971f1fdfba97690a collision-md5-file-1a
4283dd2d70af1ad3c2d5fdc917330bf502035658 collision-md5-file-1b



Real MD4 collisions
-------------------
See also:
http://www.rsasecurity.com/rsalabs/node.asp?id=2738
  Collisions for SHA0, MD5, HAVAL, MD4, and RIPEMD, but SHA1 still secure
  Aug 31, 2004

http://eprint.iacr.org/2004/199/
  Collisions for Hash Functions MD4, MD5, HAVAL-128 and RIPEMD
  Aug 17, 2004


# jacksum -a md4 collision-md4-file-0?
4d7e6a1defa93d2dde05b45d864c429b collision-md4-file-0a
4d7e6a1defa93d2dde05b45d864c429b collision-md4-file-0b

# jacksum -a sha1 collision-md4-file-0?
7226da52650d62376814f7ed687a77bee70b61e1 collision-md4-file-0a
1e4e215436b585a9f19863dfab56b2d67ffa9960 collision-md4-file-0b


# jacksum -a md4 collision-md4-file-1?
c6f3b3fe1f4833e0697340fb214fb9ea collision-md4-file-1a
c6f3b3fe1f4833e0697340fb214fb9ea collision-md4-file-1b

# jacksum -a sha1 collision-md4-file-1?
cb2c9852790f99c958e5eed5ea5edaaf5203ec86 collision-md4-file-1a
0d29e8eeb7b3a2a71c3a66bb060d7f41d1b9a473 collision-md4-file-1b



Real HAVAL 128 collisions (3 passes only)
-----------------------------------------
See also:
http://www.rsasecurity.com/rsalabs/node.asp?id=2738
  Collisions for SHA0, MD5, HAVAL, MD4, and RIPEMD, but SHA1 still secure
  Aug 31, 2004

http://eprint.iacr.org/2004/199/
  Collisions for Hash Functions MD4, MD5, HAVAL-128 and RIPEMD
  Aug 17, 2004


# jacksum -a haval_128_3 *haval_128_3*0*
6dab1e6d1b83685c89ad84d3187498b6 collision-haval_128_3-file-0a
6dab1e6d1b83685c89ad84d3187498b6 collision-haval_128_3-file-0b

# jacksum -a sha1 *haval_128_3*0*
4f3a797b7f55bc631085795dc23393820ed81fa0 collision-haval_128_3-file-0a
98d395042b101e9ecae577c7b7b50cd9e9ce7607 collision-haval_128_3-file-0b


# jacksum -a haval_128_3 *haval_128_3*1*
85830f3de1debe9992b91ff0816d4ff4 collision-haval_128_3-file-1a
85830f3de1debe9992b91ff0816d4ff4 collision-haval_128_3-file-1b

# jacksum -a sha1 *haval_128_3*1*
7ed5948b8117232bbc60dc0c9d78eaee164f2d81 collision-haval_128_3-file-1a
f7b75ad9d8d8618b40cca56f290c2607939392d8 collision-haval_128_3-file-1b


Real SHA-0 collisions
---------------------
http://theory.csail.mit.edu/~yiqun/shanote.pdf
  Collision Search Attacks on SHA1
  Feb 13, 2005

http://www.rsasecurity.com/rsalabs/node.asp?id=2738
  Collisions for SHA0, MD5, HAVAL, MD4, and RIPEMD, but SHA1 still secure
  Aug 31, 2004
  
http://eprint.iacr.org/2004/146
  Near-Collisions of SHA-0
  Jun 22, 2004  

http://fchabaud.free.fr/English/Publications/sha.pdf
  Differential collisions in SHA-0
  Jun 19, 2000  


# jacksum -a sha0 *sha0*
c9f160777d4086fe8095fba58b7e20c228a4006b collision-sha0-file0a
c9f160777d4086fe8095fba58b7e20c228a4006b collision-sha0-file0b


# jacksum -a sha1 *sha0*
af68a96f4319060b5eb6a8e1679853ac76adfbd6 collision-sha0-file0a
af8e94de546401b88942c9c116c1634b7e42e507 collision-sha0-file0b


Real CRC32 collisions
---------------------
Real collisions can be found within minutes. Don't use SFV anymore!

See also:
http://www.crc2003.250x.com/
  The CRC Faker


# jacksum -a crc32 -x *crc32-file0?
cf75bf08        1024    collision-crc32-file0a
cf75bf08        1024    collision-crc32-file0b

# jacksum -a sha1 *crc32-file0?
94fb0f56089ee4bfd7c0d3e0bac752fd17ce9429 collision-crc32-file0a
0075d378a96042b82d82b84bcdd765d096f11c9c collision-crc32-file0b


# jacksum -a crc32 -x *crc32-file1?
efb5af2e        1024    collision-crc32-file1a
efb5af2e        1024    collision-crc32-file1b

# jacksum -a sha1 *crc32-file1?
60cacbf3d72e1e7834203da608037b1bf83b40e8 collision-crc32-file1a
dd753c12c8565e73d22ab2ff2c59d44d8fdc1bfc collision-crc32-file1b
